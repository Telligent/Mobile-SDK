=========================================================================
      Zimbra Community Mobile to provide a mobile-optimized
	community experience for your internal or external audience

           		(Version 4.0.1.0)
==========================================================================

The Zimbra Community Mobile application requires a community powered by
the Zimbra Community platform of version 8.0 or
greater with a valid license.

To obtain a valid license, contact Zimbra Support
at http://telligent.com/r.ashx?63.

Product Documentation: http://telligent.com/r.ashx?78
Product Support: http://telligent.com/r.ashx?79

==========================================================================