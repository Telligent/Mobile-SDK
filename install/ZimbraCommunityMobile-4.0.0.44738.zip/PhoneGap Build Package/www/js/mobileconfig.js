window.mobileNativeConfig = {
	baseUrl: 'http://example.com/mobile/',
	domain: 'example.com',
	androidSenderId: '',
	statusTextIsDark: false
};